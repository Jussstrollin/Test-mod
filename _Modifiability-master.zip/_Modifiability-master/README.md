# Contain 4 Building that you can use
use this if you wanna have easier/harder game
this affect gold, production, science, culture, and faith
- a 10% bonus on everything for the player
- a 10% debuff on everything for the player
